

<?php $__env->startSection('content'); ?>

<div class="row">

      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4 mt-2">
                          <div class="card text-white bg-secondary mb-3" >
                              
                              <div class="card-body">
                                  <h5 class="card-title"><?php echo e($user->name); ?></h5>
                                  <p class="card-text"><?php echo e($user->email); ?></p>
                                  
                              </div>
                              </div>
                          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
  
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\hype\resources\views/dashboard/users.blade.php ENDPATH**/ ?>